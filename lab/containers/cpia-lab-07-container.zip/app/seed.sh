#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
printf '09:00:00 CONNECT 45.125.66.32:2917 119 bytes\n09:00:31 reconnect 119 bytes\n' > /labs/work/beacon.txt
