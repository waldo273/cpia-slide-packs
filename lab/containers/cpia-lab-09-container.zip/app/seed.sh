#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/disk
dd if=/dev/zero of=/labs/work/disk/ubuntu-case.img bs=1M count=16 status=none
mkfs.ext4 -q -F /labs/work/disk/ubuntu-case.img
printf 'case image ready\n' > /labs/work/disk/README.txt
