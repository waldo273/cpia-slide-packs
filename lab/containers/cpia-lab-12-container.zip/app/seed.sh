#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/samples
printf 'MZ\x90\x00' > /labs/work/samples/sample.bin
printf 'cobalt_like: jitter 20, named pipe msagent_1\n' > /labs/work/samples/profile.txt
