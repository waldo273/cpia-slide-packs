#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
printf 'KeyName\tSoftware\\Microsoft\\Windows\\CurrentVersion\\Run\n' > /labs/work/run-key.txt
printf 'EventID 4624 LogonType 10\n' > /labs/work/events.txt
