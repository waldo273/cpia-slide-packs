#!/bin/sh
set -eu
mkdir -p /labs/work /labs/artifacts /labs/sheets /labs/reports
cp /opt/cpia-lab/L*.md /labs/sheets/ 2>/dev/null || true
cp /opt/cpia-lab/srv/labs.html /labs/labs.html 2>/dev/null || true
sed -i 's#127.0.0.1:8080#127.0.0.1:8081#g; s#127.0.0.1:8010#127.0.0.1:8011#g' /labs/sheets/*.md 2>/dev/null || true

mkdir -p /labs/work
python3 - <<'PY' > /labs/work/victim-headers.txt
import socket, threading, time
srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 8081)); srv.listen(1)
def serve():
    c, _ = srv.accept(); c.recv(1024)
    c.sendall(b"HTTP/1.1 200 OK\r\nServer: Apache/2.4.52 (Debian)\r\nContent-Length: 2\r\n\r\nok")
    c.close()
threading.Thread(target=serve, daemon=True).start(); time.sleep(1)
print("connect to 127.0.0.1:8081 and read the Server header")
PY

cat > /labs/README.txt <<'EOF'
CPIA lab 03: Fingerprinting and protocol craft

  lab                 list what this lab asks for and your progress
  lab check X         submit the value you found
  /labs/work          the evidence for this lab
  /labs/sheets        the worksheet for this lab
EOF
