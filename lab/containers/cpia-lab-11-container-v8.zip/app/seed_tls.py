#!/usr/bin/env python3
"""Add a TLS session with SNI to the lab capture.

The fingerprinting lab asks the student to pull SNI names out of a capture, but the shipped capture
carries SSH and HTTP only. This appends two real-looking ClientHello records to the existing file so
the drill has something to find, without replacing the captured traffic the other labs examine.

Kept as its own file rather than inline in the Dockerfile so the heredoc quoting cannot break the
build.
"""
import os
import struct

PATH = "/labs/artifacts/2025-01-22-traffic-analysis-exercise.pcap"


def pkt(src, dst, sport, dport, payload):
    eth = (b"\x02\x00\x00\x00\x00\x02" + b"\x02\x00\x00\x00\x00\x01" + b"\x08\x00")
    total = 20 + 20 + len(payload)
    ip = struct.pack("!BBHHHBBH4s4s", 0x45, 0, total, 0, 0x4000, 64, 6, 0,
                     bytes(map(int, src.split("."))), bytes(map(int, dst.split("."))))
    tcp = struct.pack("!HHIIBBHHH", sport, dport, 1, 1, 5 << 4, 0x18, 512, 0, 0)
    return eth + ip + tcp + payload


def client_hello(sni):
    name = sni.encode()
    sni_ext = (struct.pack("!HHH", 0, len(name) + 5, len(name) + 3)
               + b"\x00" + struct.pack("!H", len(name)) + name)
    body = (b"\x03\x03" + bytes(range(32)) + b"\x00" + b"\x00\x02\x13\x01" + b"\x01\x00"
            + struct.pack("!H", len(sni_ext)) + sni_ext)
    hs = b"\x01" + struct.pack("!I", len(body))[1:] + body
    return b"\x16\x03\x01" + struct.pack("!H", len(hs)) + hs


def main():
    if not os.path.exists(PATH):
        print("no capture to extend")
        return
    data = open(PATH, "rb").read()
    if b"static-resources" in data:
        print("SNI already present, nothing to do")
        return
    header, rest = data[:24], data[24:]
    records = b""
    for sport, sni in ((51888, "cdn.static-resources.test"), (51890, "update.dyngate.test")):
        frame = pkt("172.19.0.4", "172.19.0.53", sport, 443, client_hello(sni))
        records += struct.pack("<IIII", 0, 0, 0, 0)[:8] + struct.pack("<II", len(frame), len(frame)) + frame
    open(PATH, "wb").write(header + rest + records)
    print("appended 2 TLS ClientHello records")


if __name__ == "__main__":
    main()
