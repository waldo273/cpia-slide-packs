#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
printf 'rule CPIA_Test { strings: $a = "evasion_junk_c2" condition: $a }\n' > /labs/work/rule.yar
