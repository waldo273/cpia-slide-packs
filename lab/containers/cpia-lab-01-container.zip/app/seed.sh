#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/logs /labs/artifacts
printf '2025-01-22T09:00:00Z host sshd[1001]: Accepted publickey for analyst\n' > /labs/work/logs/auth.log
printf 'engagement opened\nscope: 10.1.53.0/24\n' > /labs/work/engagement.yaml
sha256sum /labs/work/engagement.yaml > /labs/work/engagement.sha256
