#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
printf 'malfind: RWX region with MZ header at 0x400000\n' > /labs/work/memory-notes.txt
