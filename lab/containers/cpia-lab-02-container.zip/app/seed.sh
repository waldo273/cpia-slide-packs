#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
ip -brief addr > /labs/work/addressing.txt 2>/dev/null || true
ps -eo pid,comm > /labs/work/processes.txt
printf '127.0.0.1\tlocalhost\n' > /labs/work/hosts.txt
