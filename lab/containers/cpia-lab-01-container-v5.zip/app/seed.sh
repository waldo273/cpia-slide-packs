#!/bin/sh
set -eu
mkdir -p /labs/work /labs/artifacts /labs/sheets /labs/reports
cp /opt/cpia-lab/L*.md /labs/sheets/ 2>/dev/null || true
cp /opt/cpia-lab/srv/labs.html /labs/labs.html 2>/dev/null || true
cp /opt/cpia-lab/evidence/*.pcap /labs/artifacts/ 2>/dev/null || true
python3 /opt/cpia-lab/seed_tls.py 2>/dev/null || true
sed -i 's#/artifacts/#/labs/artifacts/#g; s#/work/#/labs/work/#g' /labs/sheets/*.md /opt/cpia-lab/srv/labs.html 2>/dev/null || true
sed -i 's#127.0.0.1:8080#127.0.0.1:8081#g; s#127.0.0.1:8010#127.0.0.1:8011#g' /labs/sheets/*.md 2>/dev/null || true

mkdir -p /labs/work/logs /labs/artifacts
printf '2025-01-22T09:00:00Z host sshd[1001]: Accepted publickey for analyst\n' > /labs/work/logs/auth.log
printf 'engagement opened\nscope: 10.1.53.0/24\n' > /labs/work/engagement.yaml
sha256sum /labs/work/engagement.yaml > /labs/work/engagement.sha256

cat > /labs/README.txt <<'EOF'
CPIA lab 01: Incident handling and the toolchain

  lab                 list what this lab asks for and your progress
  lab check X         submit the value you found
  /labs/work          the evidence for this lab
  /labs/sheets        the worksheet for this lab
EOF
