#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
python3 - <<'PY' > /labs/work/victim-headers.txt
import socket, threading, time
srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 8081)); srv.listen(1)
def serve():
    c, _ = srv.accept(); c.recv(1024)
    c.sendall(b"HTTP/1.1 200 OK\r\nServer: Apache/2.4.52 (Debian)\r\nContent-Length: 2\r\n\r\nok")
    c.close()
threading.Thread(target=serve, daemon=True).start(); time.sleep(1)
print("connect to 127.0.0.1:8081 and read the Server header")
PY
