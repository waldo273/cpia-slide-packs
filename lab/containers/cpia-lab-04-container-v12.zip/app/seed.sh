#!/bin/sh
set -eu
mkdir -p /labs/work /labs/artifacts /labs/sheets /labs/reports
cp /opt/cpia-lab/L*.md /labs/sheets/ 2>/dev/null || true
cp /opt/cpia-lab/srv/labs.html /labs/labs.html 2>/dev/null || true
cp /opt/cpia-lab/evidence/*.pcap /labs/artifacts/ 2>/dev/null || true
python3 /opt/cpia-lab/seed_tls.py 2>/dev/null || true
python3 /opt/cpia-lab/seed_assets.py 2>/dev/null || true
python3 /opt/cpia-lab/seed_dhcp.py 2>/dev/null || true
python3 /opt/cpia-lab/fix_flags.py 2>/dev/null || true
cp /opt/cpia-lab/evidence/fetch-evidence.sh /labs/work/ 2>/dev/null || true
chmod +x /labs/work/fetch-evidence.sh 2>/dev/null || true
sed -i 's#127.0.0.1:8080#127.0.0.1:8081#g; s#127.0.0.1:8010#127.0.0.1:8011#g' /labs/sheets/*.md 2>/dev/null || true

mkdir -p /labs/work/samples
printf 'CREST CPIA lab 04 sample\n' > /labs/work/samples/invoice.txt
openssl genrsa -out /labs/work/samples/key.pem 2048 2>/dev/null
openssl rsa -in /labs/work/samples/key.pem -pubout -out /labs/work/samples/pub.pem 2>/dev/null
sha256sum /labs/work/samples/invoice.txt > /labs/work/samples/invoice.sha256

cat > /labs/README.txt <<'EOF'
CPIA lab 04: Crypto, permissions and data formats

  lab                 list what this lab asks for and your progress
  lab check X         submit the value you found
  /labs/work          the evidence for this lab
  /labs/sheets        the worksheet for this lab
EOF
