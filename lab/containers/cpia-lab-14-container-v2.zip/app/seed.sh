#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work /labs/artifacts
printf 'reconstruction: build the timeline from the four sources in lab 06 and 09\n' > /labs/work/BRIEF.txt
