#!/bin/sh
set -eu
mkdir -p /labs/work /labs/artifacts /labs/sheets /labs/reports
cp /opt/cpia-lab/L*.md /labs/sheets/ 2>/dev/null || true
cp /opt/cpia-lab/srv/labs.html /labs/labs.html 2>/dev/null || true
cp /opt/cpia-lab/evidence/*.pcap /labs/artifacts/ 2>/dev/null || true
python3 /opt/cpia-lab/seed_tls.py 2>/dev/null || true
cp /opt/cpia-lab/evidence/fetch-evidence.sh /labs/work/ 2>/dev/null || true
chmod +x /labs/work/fetch-evidence.sh 2>/dev/null || true
sed -i 's#127.0.0.1:8080#127.0.0.1:8081#g; s#127.0.0.1:8010#127.0.0.1:8011#g' /labs/sheets/*.md 2>/dev/null || true

mkdir -p /labs/work/logs
printf 'Jan 22 09:00:01 host named[1]: client 10.1.17.215#5353: query: example.test IN A\n' > /labs/work/logs/dns.log
printf '2025-01-22T09:00:02Z proxy CONNECT 45.125.66.32:2917\n' > /labs/work/logs/proxy.log

cat > /labs/README.txt <<'EOF'
CPIA lab 06: Capture, logs and configuration

  lab                 list what this lab asks for and your progress
  lab check X         submit the value you found
  /labs/work          the evidence for this lab
  /labs/sheets        the worksheet for this lab
EOF
