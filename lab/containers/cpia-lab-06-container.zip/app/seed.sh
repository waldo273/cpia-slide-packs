#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/logs
printf 'Jan 22 09:00:01 host named[1]: client 10.1.17.215#5353: query: example.test IN A\n' > /labs/work/logs/dns.log
printf '2025-01-22T09:00:02Z proxy CONNECT 45.125.66.32:2917\n' > /labs/work/logs/proxy.log
