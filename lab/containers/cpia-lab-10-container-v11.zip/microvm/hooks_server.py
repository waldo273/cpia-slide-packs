#!/usr/bin/env python3
"""Lambda MicroVM lifecycle hooks for creator-facing Container images.

Hook paths: /aws/lambda-microvms/runtime/v1/{ready,validate,run,suspend,resume,terminate}
Listen on HOOKS_PORT (default 9000). The app listens on APP_PORT (default 8080).

This file is app-agnostic on purpose: a new image should only need a Dockerfile
that installs the app and sets APP_COMMAND / APP_PORT. Copy this whole directory and
change the Dockerfile.

How this differs from the Jupyter and Workspace hook servers, which it is otherwise
modelled on:

- /run takes no payload. Containers are stateless and anonymous — the app never learns
  which student is using it, so there is no token to pass and nothing to bootstrap. A
  /run that required a payload would 500 and the service would terminate the MicroVM.
- No callbacks to the CourseStack API. Jupyter and Workspace report readiness and
  termination over HTTP; a container is watched from the outside instead (the browser
  polls the image's health_path through the Edge, and containerMicrovmReconcilePoller
  notices VMs that die). Container images also default to no internet egress, so an
  outbound call would not even leave the VM.
"""

from __future__ import annotations

import os
import shlex
import signal
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOOK_PREFIX = '/aws/lambda-microvms/runtime/v1'
HOOKS_PORT = int(os.environ.get('HOOKS_PORT', '9000'))
APP_PORT = int(os.environ.get('APP_PORT', '8080'))
APP_NAME = os.environ.get('APP_NAME', 'app')
# Set by the Dockerfile. Runs in the foreground; this server supervises it.
APP_COMMAND = os.environ.get('APP_COMMAND', '')
APP_START_TIMEOUT_SECONDS = int(os.environ.get('APP_START_TIMEOUT_SECONDS', '60'))

_lock = threading.Lock()
_state = {
    'ready': False,
    'bootstrap_error': None,
    'app_proc': None,
}


def _log(message: str) -> None:
    print(f'[catalog-hooks] {message}', flush=True)


def _app_listening() -> bool:
    try:
        with socket.create_connection(('127.0.0.1', APP_PORT), timeout=1):
            return True
    except OSError:
        return False


def _stop_app() -> None:
    with _lock:
        proc = _state['app_proc']
        _state['app_proc'] = None

    if proc and proc.poll() is None:
        _log(f'Stopping {APP_NAME}')
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def _start_app() -> None:
    if not APP_COMMAND:
        raise RuntimeError('APP_COMMAND is not set; the image must define it')

    _log(f'Starting {APP_NAME} on port {APP_PORT}: {APP_COMMAND}')
    proc = subprocess.Popen(shlex.split(APP_COMMAND))
    with _lock:
        _state['app_proc'] = proc

    deadline = time.time() + APP_START_TIMEOUT_SECONDS
    while time.time() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(f'{APP_NAME} exited early with code {proc.returncode}')
        if _app_listening():
            _log(f'{APP_NAME} is listening')
            return
        time.sleep(0.1)

    raise RuntimeError(f'Timed out waiting for {APP_NAME} to listen on {APP_PORT}')


def _ensure_app() -> None:
    if _app_listening():
        return
    _log(f'{APP_NAME} not listening; starting')
    _start_app()


def _handle_ready() -> int:
    if _state['bootstrap_error']:
        _log('ready → 500 (bootstrap_error)')
        return 500
    if _state['ready']:
        _log('ready → 200')
        return 200
    _log(f'ready → 503 (waiting for warm {APP_NAME})')
    return 503


def _handle_validate() -> int:
    if not _state['ready']:
        return 503
    if not _app_listening():
        _log(f'validate: {APP_NAME} not listening')
        return 503
    return 200


def _handle_run() -> int:
    """Deliberately ignores the request body — see the module docstring."""
    _ensure_app()
    return 200


def _handle_suspend() -> int:
    return 200


def _handle_resume() -> int:
    _ensure_app()
    return 200


def _handle_terminate() -> int:
    _stop_app()
    return 200


class HookHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:
        _log(f'{self.address_string()} {format % args}')

    def do_POST(self) -> None:  # noqa: N802
        path = self.path.split('?', 1)[0].rstrip('/')
        length = int(self.headers.get('Content-Length', '0') or '0')
        if length > 0:
            self.rfile.read(length)

        routes = {
            f'{HOOK_PREFIX}/ready': _handle_ready,
            f'{HOOK_PREFIX}/validate': _handle_validate,
            f'{HOOK_PREFIX}/run': _handle_run,
            f'{HOOK_PREFIX}/suspend': _handle_suspend,
            f'{HOOK_PREFIX}/resume': _handle_resume,
            f'{HOOK_PREFIX}/terminate': _handle_terminate,
        }

        handler = routes.get(path)
        if handler is None:
            self.send_response(404)
            self.end_headers()
            return

        try:
            status = handler()
        except Exception as error:  # noqa: BLE001 — a raise here must not hang the hook
            _log(f'Hook {path} failed: {error}')
            self.send_response(500)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(str(error).encode('utf-8'))
            return

        self.send_response(status)
        self.end_headers()


def _bootstrap_warm_app() -> None:
    """Start the app before the snapshot so students get a warm boot."""
    try:
        _start_app()
        with _lock:
            _state['ready'] = True
            _state['bootstrap_error'] = None
        _log(f'Warm {APP_NAME} ready for snapshot')
    except Exception as error:  # noqa: BLE001 — reported through /ready
        _log(f'Warm {APP_NAME} failed: {error}')
        with _lock:
            _state['ready'] = False
            _state['bootstrap_error'] = str(error)


def main() -> None:
    _log(f'Listening for hooks on :{HOOKS_PORT} ({APP_NAME} on :{APP_PORT})')
    threading.Thread(target=_bootstrap_warm_app, daemon=True).start()
    server = ThreadingHTTPServer(('0.0.0.0', HOOKS_PORT), HookHandler)
    server.serve_forever()


if __name__ == '__main__':
    main()
