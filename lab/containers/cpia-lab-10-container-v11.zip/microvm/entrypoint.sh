#!/bin/bash
set -euo pipefail

export HOOKS_PORT="${HOOKS_PORT:-9000}"
export APP_PORT="${APP_PORT:-8080}"
export APP_NAME="${APP_NAME:-app}"

export PYTHONUNBUFFERED=1
echo "[catalog-microvm] starting hooks server (hooks=${HOOKS_PORT}, ${APP_NAME}=${APP_PORT})"
exec python3 -u /usr/local/bin/hooks_server.py
