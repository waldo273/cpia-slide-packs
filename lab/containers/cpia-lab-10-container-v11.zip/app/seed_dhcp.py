#!/usr/bin/env python3
"""Append a DHCP exchange carrying a known client MAC, so Lab 02's flag can be found.

Lab 02 asks for the client MAC in the capture, lower case hex with no separators. The shipped
capture has SSH, HTTP, ARP and TLS but no DHCP, so the drill's own command returned nothing.
This adds a real DHCP DISCOVER/REQUEST from a fixed client, and fix_flags.py makes that MAC the
expected answer.

Run once at first boot:  python3 /opt/cpia-lab/seed_dhcp.py
"""
import os
import struct

PATH = "/labs/artifacts/2025-01-22-traffic-analysis-exercise.pcap"
CLIENT_MAC = bytes.fromhex("0242ac110003")
BROADCAST = b"\xff" * 6


def dhcp_packet(src_mac, xid, message_type):
    eth = BROADCAST + src_mac + b"\x08\x00"
    # DHCP carries a fixed 236-byte BOOTP body plus the magic cookie and options
    bootp = struct.pack("!BBBBIHH", 1, 1, 6, 0, xid, 0, 0)
    bootp += b"\x00" * 16                      # ciaddr, yiaddr, siaddr, giaddr
    bootp += src_mac + b"\x00" * 10            # chaddr padded to 16
    bootp += b"\x00" * 192                     # server name and file
    bootp += b"\x63\x82\x53\x63"               # magic cookie
    bootp += bytes([53, 1, message_type, 255])
    payload = bootp
    udp = struct.pack("!HHHH", 68, 67, 8 + len(payload), 0) + payload
    ip = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(udp), 0, 0x4000, 64, 17, 0,
                     bytes([0, 0, 0, 0]), bytes([255, 255, 255, 255]))
    return eth + ip + udp


def main():
    if not os.path.exists(PATH):
        print("no capture to extend")
        return
    data = open(PATH, "rb").read()
    if b"\x02\x42\xac\x11\x00\x03" in data:
        print("capture already carries the client MAC")
        return
    records = b""
    for xid, mtype in ((0x1A2B3C4D, 1), (0x1A2B3C4D, 3)):
        frame = dhcp_packet(CLIENT_MAC, xid, mtype)
        records += struct.pack("<IIII", 0, 0, 0, 0)[:8] + struct.pack("<II", len(frame), len(frame)) + frame
    with open(PATH, "wb") as fh:
        fh.write(data[:24] + data[24:] + records)
    print("appended DHCP DISCOVER and REQUEST")


if __name__ == "__main__":
    main()
