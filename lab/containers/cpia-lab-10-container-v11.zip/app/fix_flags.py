#!/usr/bin/env python3
"""Recompute the two flags whose answer depends on this container's own evidence.

Lab 01 asks for the first eight characters of the sample's SHA-256, and Lab 02 for the client MAC
in the capture. Both are derived from files this container generated, so the hash baked into the
shared flags.json describes the appliance's originals and can never be satisfied here.

This rewrites only those two entries, keeping the salt, so `lab check` grades the value a student can
actually find in this container.

Run after the fixtures exist:  python3 /opt/cpia-lab/fix_flags.py
"""
import hashlib
import json
import os

FLAGS = "/usr/local/share/cpia/flags.json"
SAMPLE = "/labs/artifacts/malware/samples/wsrdropper_2025.bin"
CLIENT_MAC = "0242ac110003"          # written into the capture by seed_dhcp.py


def digest(entry, value):
    return hashlib.sha256((entry["salt"] + value.strip().lower()).encode()).hexdigest()


def main():
    if not os.path.exists(FLAGS):
        print("no flags file")
        return
    flags = json.load(open(FLAGS))
    answers = {}
    if os.path.exists(SAMPLE):
        answers["L01"] = hashlib.sha256(open(SAMPLE, "rb").read()).hexdigest()[:8]
    answers["L02"] = CLIENT_MAC
    changed = []
    for lab, value in answers.items():
        if lab in flags:
            flags[lab]["sha256"] = digest(flags[lab], value)
            flags[lab]["derived_from_container"] = True
            changed.append(lab)
    json.dump(flags, open(FLAGS, "w"), indent=1)
    print(f"flags derived from container evidence: {', '.join(changed)}")


if __name__ == "__main__":
    main()
