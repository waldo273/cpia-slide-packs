#!/bin/sh
# Stage this lab's evidence into the working tree and record what is there.
#
# The container already holds the evidence at /labs/artifacts, so this copies it into /labs/work,
# where the worksheets tell you to work, and writes a manifest you can quote in a report.
#
#   sh /labs/work/fetch-evidence.sh          stage everything
#   sh /labs/work/fetch-evidence.sh 3        stage and label the manifest for lab 3
set -e

LAB="${1:-unknown}"
REPORTS=/labs/work/reports
mkdir -p "$REPORTS"

if [ -d /labs/artifacts ]; then
    cp -R /labs/artifacts/. /labs/work/ 2>/dev/null || true
fi

{
    echo "CPIA lab evidence manifest"
    echo "lab:      $LAB"
    echo "captured: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
    echo
    echo "files staged in /labs/work:"
    find /labs/work -maxdepth 3 -type f ! -name 'evidence-manifest.txt' -printf '  %10s  %p\n' 2>/dev/null \
        || ls -lR /labs/work
} > "$REPORTS/evidence-manifest.txt"

echo "Evidence staged in /labs/work"
echo "Manifest: $REPORTS/evidence-manifest.txt"
sed -n '1,20p' "$REPORTS/evidence-manifest.txt"
