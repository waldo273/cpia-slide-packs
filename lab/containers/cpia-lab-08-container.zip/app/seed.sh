#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work
printf '09:00 SYN 10.1.17.215:51000 -> 445\n09:01 SYN 10.1.17.215:51002 -> 445\n' > /labs/work/scan.txt
