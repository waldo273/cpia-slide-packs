#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/samples
printf 'CREST CPIA lab 04 sample\n' > /labs/work/samples/invoice.txt
openssl genrsa -out /labs/work/samples/key.pem 2048 2>/dev/null
openssl rsa -in /labs/work/samples/key.pem -pubout -out /labs/work/samples/pub.pem 2>/dev/null
sha256sum /labs/work/samples/invoice.txt > /labs/work/samples/invoice.sha256
