#!/bin/sh
set -eu
mkdir -p /labs/work /labs/artifacts /labs/sheets /labs/reports
cp /opt/cpia-lab/L*.md /labs/sheets/ 2>/dev/null || true
cp /opt/cpia-lab/srv/labs.html /labs/labs.html 2>/dev/null || true
cp /opt/cpia-lab/evidence/*.pcap /labs/artifacts/ 2>/dev/null || true
python3 /opt/cpia-lab/seed_tls.py 2>/dev/null || true
sed -i 's#/artifacts/#/labs/artifacts/#g; s#/work/#/labs/work/#g' /labs/sheets/*.md /opt/cpia-lab/srv/labs.html 2>/dev/null || true
sed -i 's#127.0.0.1:8080#127.0.0.1:8081#g; s#127.0.0.1:8010#127.0.0.1:8011#g' /labs/sheets/*.md 2>/dev/null || true

mkdir -p /labs/work/disk
dd if=/dev/zero of=/labs/work/disk/ubuntu-case.img bs=1M count=16 status=none
mkfs.ext4 -q -F /labs/work/disk/ubuntu-case.img
printf 'case image ready\n' > /labs/work/disk/README.txt

cat > /labs/README.txt <<'EOF'
CPIA lab 09: Acquisition and Linux artefacts

  lab                 list what this lab asks for and your progress
  lab check X         submit the value you found
  /labs/work          the evidence for this lab
  /labs/sheets        the worksheet for this lab
EOF
