#!/bin/sh
# CourseStack entrypoint for the CPIA lab container.
#
# The platform expects this script to start the lifecycle hook server, keep it running, and run
# the learner app in the foreground on APP_PORT. Order matters: hooks first, so the platform can
# see the container while the app boots.
set -eu

APP_PORT="${APP_PORT:-8080}"
HOOKS_PORT="${HOOKS_PORT:-9000}"
APP_COMMAND="${APP_COMMAND:-ttyd -p ${APP_PORT} -W lab}"

mkdir -p /labs/reports /labs/work /labs/artifacts /var/log

echo "[entrypoint] ${APP_NAME:-cpia-lab} starting: hooks ${HOOKS_PORT}, app ${APP_PORT}"

python3 /usr/local/bin/hooks_server.py >>/var/log/hooks.log 2>&1 &
HOOKS_PID=$!

# the evidence services: page on 8011, victim web on 8081, kept inside the container
if [ -f /opt/cpia-lab/srv/server.py ]; then
    EVIDENCE_PORT=8011 LAB_ROOT=/opt/cpia-lab nohup python3 /opt/cpia-lab/srv/server.py \
        >>/var/log/evidence.log 2>&1 &
fi

# a container that loses its hooks server looks dead to the platform, so restart it once
( while kill -0 "$HOOKS_PID" 2>/dev/null; do sleep 5; done
  echo "[entrypoint] hooks died, restarting" >>/var/log/hooks.log
  exec python3 /usr/local/bin/hooks_server.py >>/var/log/hooks.log 2>&1 ) &

echo "[entrypoint] app command: ${APP_COMMAND}"
exec sh -c "${APP_COMMAND}"
