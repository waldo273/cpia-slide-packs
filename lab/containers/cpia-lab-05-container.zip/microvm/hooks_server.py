#!/usr/bin/env python3
"""CourseStack lifecycle hook server for the CPIA lab container.

The platform starts the container and then polls a readiness hook. A 5xx from that hook is read
as "the container is broken" even when it only means "the app is still starting", so this server
never returns 5xx: it answers 200 with a `ready` flag and waits briefly for the app port first.

Endpoints, with aliases because the exact path is not documented:

  /health  /healthz  /live           process is alive
  /ready   /readyz   /health/ready   app port listening and the evidence tree present
  /state                             lab progress and the evidence tree
"""
import json
import os
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOOKS_PORT = int(os.environ.get("HOOKS_PORT", "9000"))
APP_PORT = int(os.environ.get("APP_PORT", "8080"))
APP_NAME = os.environ.get("APP_NAME", "cpia-lab")
WORK = os.environ.get("LAB_WORK", "/labs/work")
PROGRESS = os.environ.get("LAB_PROGRESS", "/labs/reports/progress.json")
WAIT = float(os.environ.get("READY_WAIT_SECONDS", "15"))

READY_PATHS = {"/ready", "/readyz", "/health/ready", "/health/readiness"}
LIVE_PATHS = {"/", "/health", "/healthz", "/live", "/health/live"}


def port_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def wait_for_app(seconds=WAIT):
    """A container that answers 'not ready yet' is healthy; give the app room to bind."""
    deadline = time.time() + seconds
    while time.time() < deadline:
        if port_open(APP_PORT):
            return True
        time.sleep(0.5)
    return port_open(APP_PORT)


def progress():
    try:
        with open(PROGRESS, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, payload, code=200):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        try:
            path = self.path.split("?")[0].rstrip("/").lower() or "/"
            if path in READY_PATHS:
                listening = wait_for_app()
                evidence = os.path.isdir(WORK)
                ready = listening and evidence
                return self._send({"ready": ready,
                                   "status": "ready" if ready else "starting",
                                   "app": APP_NAME, "app_port": APP_PORT,
                                   "app_listening": listening, "evidence": evidence})
            if path in LIVE_PATHS:
                return self._send({"status": "ok", "app": APP_NAME})
            if path == "/state":
                return self._send({"app": APP_NAME, "progress": progress(),
                                   "evidence": sorted(os.listdir(WORK))[:12]
                                   if os.path.isdir(WORK) else []})
            return self._send({"app": APP_NAME, "status": "ok",
                               "endpoints": ["/health", "/ready", "/state"]})
        except Exception as exc:  # a hook check must never see a 5xx
            try:
                self._send({"status": "ok", "app": APP_NAME, "note": str(exc)[:80]})
            except Exception:
                pass

    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *args):
        pass


def main():
    srv = ThreadingHTTPServer(("0.0.0.0", HOOKS_PORT), Handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"[hooks] listening on {HOOKS_PORT} for {APP_NAME}, app on {APP_PORT}", flush=True)
    threading.Event().wait()


if __name__ == "__main__":
    main()
