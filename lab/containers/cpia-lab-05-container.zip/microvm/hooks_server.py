#!/usr/bin/env python3
"""CourseStack lifecycle hook server for the CPIA lab container.

CourseStack starts the container with this server on HOOKS_PORT (9000) and the learner app on
APP_PORT (8080), both in the foreground. This implementation stays deliberately small: it
answers health and readiness so the platform can tell whether the lab has come up, exposes the
lab's own state, and never blocks the app.

Endpoints
  GET /health      process is alive
  GET /ready       the app port answers and the evidence tree exists
  GET /state       lab progress, flags found, services running
  GET /            人类-friendly summary
"""
import json
import os
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOOKS_PORT = int(os.environ.get("HOOKS_PORT", "9000"))
APP_PORT = int(os.environ.get("APP_PORT", "8080"))
APP_NAME = os.environ.get("APP_NAME", "cpia-lab")
WORK = os.environ.get("LAB_WORK", "/labs/work")
PROGRESS = os.environ.get("LAB_PROGRESS", "/labs/reports/progress.json")


def port_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def progress():
    try:
        with open(PROGRESS, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0].rstrip("/") or "/"
        if path == "/health":
            return self._send(200, {"status": "ok", "app": APP_NAME})
        if path == "/ready":
            ready = port_open(APP_PORT) and os.path.isdir(WORK)
            return self._send(200 if ready else 503,
                              {"ready": ready, "app_port": APP_PORT,
                               "app_listening": port_open(APP_PORT),
                               "evidence": os.path.isdir(WORK)})
        if path == "/state":
            return self._send(200, {"app": APP_NAME, "progress": progress(),
                                    "evidence": sorted(os.listdir(WORK))[:12]
                                    if os.path.isdir(WORK) else []})
        return self._send(200, {"app": APP_NAME, "endpoints": ["/health", "/ready", "/state"]})

    def log_message(self, *args):
        pass


def main():
    srv = ThreadingHTTPServer(("0.0.0.0", HOOKS_PORT), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    # stay in the foreground: the platform watches this process
    threading.Event().wait()


if __name__ == "__main__":
    main()
