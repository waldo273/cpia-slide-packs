#!/bin/sh
set -eu
mkdir -p /labs/reports /labs/artifacts

mkdir -p /labs/work/docs
printf 'author: analyst\ncreated: 2025-01-22\n' > /labs/work/docs/author.txt
printf 'Registrar: Example Registrar\nCreated: 2024-11-02\n' > /labs/work/docs/whois.txt
